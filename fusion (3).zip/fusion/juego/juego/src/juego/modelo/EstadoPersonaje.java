package juego.modelo;

public interface EstadoPersonaje {
    String getNombre();
    int getDuracion();
    boolean aplicarEfecto(Personaje p);
    int getBonoAtaque();
}