package juego.modelo;

public class EstadoAumentarFuerza implements EstadoPersonaje {

    @Override
    public String getNombre() {
        return "Aumentar Fuerza";
    }

    @Override
    public int getDuracion() {
        return 3;
    }

    @Override
    public boolean aplicarEfecto(Personaje p) {

        System.out.println(
            p.getNombre() + " esta fortalecido (+10 ataque)"
        );

        return true;
    }

    @Override
    public int getBonoAtaque() {
        return 10;
    }
}