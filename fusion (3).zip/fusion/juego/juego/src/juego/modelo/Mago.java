package juego.modelo;

import java.util.Random;

public class Mago extends Personaje {

    private static final String[] nombres = {
        "Gandalf",
        "Merlin",
        "Saruman",
        "Dumbledore",
        "Morgana",
        "Zatanna",
        "Rincewind",
        "Elminster",
        "Raistlin",
        "Prospero"
    };

    private static final String[] ataques = {
        "bola de fuego",
        "rayo magico",
        "explosion arcana",
        "descarga mistica",
        "chispa oscura",
        "hechizo elemental",
        "luz divina",
        "energia arcana",
        "impacto magico",
        "pulso de mana"
    };

    public Mago() {

        super(
            nombres[new Random().nextInt(nombres.length)],
            90,
            20,
            5,
            "Mago",
            new Objeto[] {
                new Arma("Baston", 50),
                new Arma("Varita", 15),
                new Armadura("Toga", 5),
                new Armadura("Tunica", 20)
            }[new Random().nextInt(4)]
        );

        Random r = new Random();
        this.nombreAtaque = ataques[r.nextInt(ataques.length)];
    }

    @Override
    public int atacar() {
        return ataque + 10 + getBonoAtaque();
    }

    @Override
    protected int habilidadEspecial() {
        return ataque + 30 + getBonoAtaque();
    }

    @Override
    public String nombreHabilidad() {
        return "HECHIZO ARCANO!!!!";
    }

    @Override
    public void aplicarEstadoEspecial(Personaje objetivo) {

        if (Math.random() < 0.5) {

            objetivo.aplicarEstado(new EstadoQuemado());

            System.out.println(
                objetivo.getNombre()
                + " ahora esta: Quemado"
            );

        } else {

            objetivo.aplicarEstado(new EstadoCongelado());

            System.out.println(
                objetivo.getNombre()
                + " ahora esta: Congelado"
            );
        }
    }
}