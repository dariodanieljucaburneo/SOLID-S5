package juego.modelo;

import java.util.Random;

public class Guerrero extends Personaje implements AutoMejorable {

    private static final String[] nombres = {
        "Kratos",
        "Ares",
        "Leonidas",
        "Hector",
        "Conan",
        "Thor",
        "Maximus",
        "Spartacus",
        "Ajax",
        "Ragnar"
    };

    private static final String[] ataques = {
        "cabezaso fuerte",
        "golpe devastador",
        "espadazo brutal",
        "corte feroz",
        "embestida salvaje",
        "ataque pesado",
        "golpe de guerra",
        "choque violento",
        "fuerza titanica",
        "impacto demoledor"
    };

    public Guerrero() {

        super(
            nombres[new Random().nextInt(nombres.length)],
            100,
            15,
            10,
            "Guerrero",
            new Objeto[] {
                new Arma("Espada corta", 15),
                new Arma("Espada larga", 25),
                new Armadura("Casco", 15),
                new Armadura("Guanteletes", 10)
            }[new Random().nextInt(4)]
        );

        Random r = new Random();
        this.nombreAtaque = ataques[r.nextInt(ataques.length)];
    }

    @Override
    public int atacar() {
        return ataque + 5 + getBonoAtaque();
    }

    @Override
    protected int habilidadEspecial() {
        return ataque + 20 + getBonoAtaque();
    }

    @Override
    public String nombreHabilidad() {
        return "GOLPE BRUTAL!!!!";
    }

    @Override
    public void aplicarEstadoEspecial(Personaje objetivo) {

        objetivo.aplicarEstado(new EstadoDebilitado());

        System.out.println(
            objetivo.getNombre() + " ahora esta: Debilitado"
        );
    }

    @Override
    public void mejorarseASiMismo() {

        this.aplicarEstado(new EstadoAumentarFuerza());

        System.out.println(
            this.getNombre() + " ahora esta: Aumentar Fuerza"
        );
    }
}