package juego.modelo;

public class EstadoCongelado implements EstadoPersonaje {

    @Override
    public String getNombre() {
        return "Congelado";
    }

    @Override
    public int getDuracion() {
        return 1;
    }

    @Override
    public boolean aplicarEfecto(Personaje p) {

        System.out.println(
            p.getNombre() + " esta congelado y pierde su turno"
        );

        return false;
    }

    @Override
    public int getBonoAtaque() {
        return 0;
    }
}