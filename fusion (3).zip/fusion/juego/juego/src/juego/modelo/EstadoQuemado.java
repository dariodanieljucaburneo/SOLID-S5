package juego.modelo;

public class EstadoQuemado implements EstadoPersonaje {

    @Override
    public String getNombre() {
        return "Quemado";
    }

    @Override
    public int getDuracion() {
        return 3;
    }

    @Override
    public boolean aplicarEfecto(Personaje p) {

        p.recibirDanioDirecto(3);

        System.out.println(
            p.getNombre() + " sufre danio por quemadura (-3 vida)"
        );

        return true;
    }

    @Override
    public int getBonoAtaque() {
        return 0;
    }
}