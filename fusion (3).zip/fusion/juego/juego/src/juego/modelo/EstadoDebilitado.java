package juego.modelo;

public class EstadoDebilitado implements EstadoPersonaje {

    @Override
    public String getNombre() {
        return "Debilitado";
    }

    @Override
    public int getDuracion() {
        return 3;
    }

    @Override
    public boolean aplicarEfecto(Personaje p) {

        System.out.println(
            p.getNombre() + " esta debilitado (-5 ataque)"
        );

        return true;
    }

    @Override
    public int getBonoAtaque() {
        return -5;
    }
}