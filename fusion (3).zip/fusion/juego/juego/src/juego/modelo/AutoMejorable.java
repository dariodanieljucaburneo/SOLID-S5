package juego.modelo;

public interface AutoMejorable {

    void mejorarseASiMismo();

}