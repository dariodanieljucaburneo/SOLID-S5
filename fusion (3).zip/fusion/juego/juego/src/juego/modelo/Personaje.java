package juego.modelo;

public abstract class Personaje
        implements Atacante,
                   Defensor,
                   ConHabilidad,
                   GeneradorEstado {
    protected String nombre;
    protected int vida;
    protected int ataque;
    protected int defensa;
    protected int nivel;
    protected String tipo;

    protected int energia;
    protected int maxEnergia = 100;
    protected int cooldown = 0;

    protected EstadoPersonaje estado = new EstadoNormal();
    protected int turnosEstado = 0;

    protected Objeto obj;
    protected String nombreAtaque;

    public Personaje(String nombre,
                     int vida,
                     int ataque,
                     int defensa,
                     String tipo,
                     Objeto obj) {

        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque + obj.getAtq();
        this.defensa = defensa + obj.getDef();
        this.tipo = tipo;
        this.obj = obj;

        this.nivel = (int)(Math.random() * 100) + 1;
        this.energia = maxEnergia;
    }

    @Override
    public abstract int atacar();

    @Override
    public void defender(int danio) {

        int danioFinal = danio - defensa;

        if (danioFinal < 0) {
            danioFinal = 0;
        }

        vida -= danioFinal;

        if (vida < 0) {
            vida = 0;
        }
    }

    @Override
    public int usarHabilidadEspecial() throws Exception {

        if (energia < 20) {
            throw new Exception("Sin energia");
        }

        if (cooldown > 0) {
            throw new Exception("Habilidad en cooldown");
        }

        energia -= 20;
        cooldown = 2;

        return habilidadEspecial();
    }

    protected abstract int habilidadEspecial();

    @Override
    public abstract String nombreHabilidad();

    @Override
    public abstract void aplicarEstadoEspecial(Personaje objetivo);

    public void reducirCooldown() {

        if (cooldown > 0) {
            cooldown--;
        }
    }

    public boolean aplicarEfectosEstado() {

        boolean puedeActuar = estado.aplicarEfecto(this);

        turnosEstado--;

        if (turnosEstado <= 0 && !(estado instanceof EstadoNormal)) {
            estado = new EstadoNormal();
            turnosEstado = 0;
        }

        return puedeActuar;
    }

    public void aplicarEstado(EstadoPersonaje nuevoEstado) {

        this.estado = nuevoEstado;
        this.turnosEstado = nuevoEstado.getDuracion();
    }

    public void recibirDanioDirecto(int cantidad) {

        vida -= cantidad;

        if (vida < 0) {
            vida = 0;
        }
    }

    public int getBonoAtaque() {
        return estado.getBonoAtaque();
    }

    public void resetearEstado() {

        estado = new EstadoNormal();
        turnosEstado = 0;
        energia = maxEnergia;
        cooldown = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public int getVida() {
        return vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public int getNivel() {
        return nivel;
    }

    public String getTipo() {
        return tipo;
    }

    public int getEnergia() {
        return energia;
    }

    public int getCooldown() {
        return cooldown;
    }

    public String getEstado() {
        return estado.getNombre();
    }

    public String getNombreAtaque() {
        return nombreAtaque;
    }

    public Objeto getObjeto() {
        return obj;
    }

    @Override
    public String toString() {

        return nombre + " [" + tipo + "]"
                + " | Vida: " + vida
                + " | Nivel: " + nivel
                + " | Ataque: " + ataque
                + " | Defensa: " + defensa
                + " | Energia: " + energia
                + " | Objeto: " + obj.getNombre()
                + " [" + obj.getTipo() + "]";
    }
}