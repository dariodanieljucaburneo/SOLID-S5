package juego.modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

public class FabricaPersonajes {

    private static final List<Supplier<Personaje>> registro = new ArrayList<>();

    static {
        registrar(Guerrero::new);
        registrar(Mago::new);
        registrar(Arquero::new);
    }

    public static void registrar(Supplier<Personaje> generador) {
        registro.add(generador);
    }

    public static Personaje crearAleatorio(Random rand) {
        return registro.get(rand.nextInt(registro.size())).get();
    }

    public static int cantidadDisponibles() {
        return registro.size();
    }
}