package juego.modelo;

public class EstadoNormal implements EstadoPersonaje {

    @Override
    public String getNombre() {
        return "Normal";
    }

    @Override
    public int getDuracion() {
        return 0;
    }

    @Override
    public boolean aplicarEfecto(Personaje p) {
        return true;
    }

    @Override
    public int getBonoAtaque() {
        return 0;
    }
}