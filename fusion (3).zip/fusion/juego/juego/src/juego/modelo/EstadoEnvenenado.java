package juego.modelo;

public class EstadoEnvenenado implements EstadoPersonaje {

    @Override
    public String getNombre() {
        return "Envenenado";
    }

    @Override
    public int getDuracion() {
        return 3;
    }

    @Override
    public boolean aplicarEfecto(Personaje p) {

        p.recibirDanioDirecto(5);

        System.out.println(
            p.getNombre() + " sufre danio por veneno (-5 vida)"
        );

        return true;
    }

    @Override
    public int getBonoAtaque() {
        return 0;
    }
}